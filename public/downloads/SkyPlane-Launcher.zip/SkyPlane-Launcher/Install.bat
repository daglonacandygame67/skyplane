@echo off
title SkyPlane SMP installer
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install.ps1"
pause
